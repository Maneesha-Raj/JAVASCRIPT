function square(a){
    let p1=4*a;
    return p1;
}

function rect(l,b){
    let p2=2*(l+b);
    return p2;

}

function circle(r){
    let p3=2*3.14*r;
    return p3;
    
}