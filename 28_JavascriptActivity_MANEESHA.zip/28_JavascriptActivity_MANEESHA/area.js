function square(a){
    let a1=a*a;
    return a1;
}

function rect(l,b){
    let a2=l*b;
    return a2;

}

function circle(r){
    let a3=3.14*r*r;
    return a3;
}