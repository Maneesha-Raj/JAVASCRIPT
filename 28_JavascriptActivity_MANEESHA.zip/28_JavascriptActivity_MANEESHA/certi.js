function readval(){
    let course=document.getElementById("id1").value;
    let cid=document.getElementById("id2").value;
    let cname=document.getElementById("id3").value;
    let g=document.getElementById("id4").value;
    let d=document.getElementById("id5").value;
    console.log("<br>Course :",course);
    console.log("<br>Certificate Id :",cid);
    console.log("<br>Candidate Name :",cname);
    console.log("<br>Grade :",g);
    console.log("<br>Issue Date :",d);

}